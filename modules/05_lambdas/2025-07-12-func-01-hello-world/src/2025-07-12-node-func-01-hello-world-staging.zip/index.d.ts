import "dotenv/config";
export declare const handler: (event: any, context: any) => Promise<{
    statusCode: number;
    body: string;
}>;

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
require("dotenv/config");
// console.log("process.env in index.ts");
// console.log(process.env);
const handler = async (event, context) => {
    console.log("event", event);
    console.log("context", context);
    return {
        statusCode: 200,
        body: JSON.stringify("Hello World from nodejs20"),
    };
};
exports.handler = handler;

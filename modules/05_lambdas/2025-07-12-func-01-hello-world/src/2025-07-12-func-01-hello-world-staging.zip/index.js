"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("dotenv/config");
// console.log("process.env in index.ts");
// console.log(process.env);
// @ts-ignore: not found awslambda
exports.handler = awslambda.streamifyResponse(async (event, responseStream, _context) => {
    try {
        console.log("hit lambdas/index.ts handler");
        responseStream.write("Hello World !");
    }
    catch (error) {
        responseStream.write(JSON.stringify({ error: error.message }));
    }
    responseStream.end();
});

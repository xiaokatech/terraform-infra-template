# 2025-07-12-func-01-hello-world

## Env

```bash
python3 -m venv venv
```

## Test

```bash
pytest tests/unit/

# Need deploy first: terraform apply for environment
pytest tests/integration/
```
